// Runs on the school system pages — sync Supabase session into extension storage.
(function () {
  if (!self.sbTrustedSchoolUrl(location.href)) return;
  // ค้นหา backend จาก localStorage ของหน้าเว็บ (ไม่ hardcode project อีกต่อไป)
  function detect() {
    let ref = null, url = "", anon = "";
    try {
      const cfg = JSON.parse(localStorage.getItem("bng.backend.config") || "{}");
      if (cfg.url) url = String(cfg.url).replace(/\/+$/, "");
      if (cfg.anonKey) anon = cfg.anonKey;
    } catch {}
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i) || "";
      const m = k.match(/^sb-(.+)-auth-token$/);
      if (m) { ref = m[1]; break; }
    }
    if (!url && ref) url = `https://${ref}.supabase.co`;
    return { ref, url, anon };
  }

  let DET = detect();
  let KEY = DET.ref ? `sb-${DET.ref}-auth-token` : "";
  let SUPA_URL = DET.url;
  let ANON = DET.anon;

  // ดึง anon key จาก /app-config.js ของหน้าเว็บ (content script อ่าน window ของเพจไม่ได้)
  async function loadConfig() {
    const backend = await chrome.runtime.sendMessage({ type: "GET_BACKEND" });
    if (!backend?.url || !backend?.anonKey) throw new Error("ไม่พบระบบโรงเรียน");
    SUPA_URL = backend.url; ANON = backend.anonKey;
    KEY = `sb-${new URL(SUPA_URL).hostname.split(".")[0]}-auth-token`;
  }

  function read() {
    if (!KEY) { DET = detect(); KEY = DET.ref ? `sb-${DET.ref}-auth-token` : ""; SUPA_URL = SUPA_URL || DET.url; }
    if (!KEY) return null;
    try {
      const raw = localStorage.getItem(KEY);
      if (!raw) return null;
      const parsed = JSON.parse(raw);
      // supabase-js v2 stores {access_token, refresh_token, expires_at, user, ...}
      if (parsed?.access_token) return parsed;
      if (parsed?.currentSession?.access_token) return parsed.currentSession;
      return null;
    } catch { return null; }
  }


  async function fetchProfile(userId, token) {
    const out = { name: null, role: null };
    try {
      const r = await fetch(`${SUPA_URL}/rest/v1/profiles?id=eq.${userId}&select=first_name,last_name,nickname`, {
        headers: { apikey: ANON, Authorization: `Bearer ${token}` },
      });
      if (!r.ok) throw new Error("อ่านชื่อไม่สำเร็จ");
      const arr = await r.json();
      const p = arr?.[0];
      if (p) {
        const nick = p.nickname ? ` (${p.nickname})` : "";
        out.name = `${p.first_name || ""} ${p.last_name || ""}${nick}`.trim() || null;
      }
    } catch { /* ignore */ }
    try {
      const r2 = await fetch(`${SUPA_URL}/rest/v1/user_roles?user_id=eq.${userId}&select=role`, {
        headers: { apikey: ANON, Authorization: `Bearer ${token}` },
      });
      if (!r2.ok) throw new Error("อ่านบทบาทไม่สำเร็จ");
      const rows = await r2.json();
      const roles = Array.isArray(rows) ? rows.map((x) => x.role) : [];
      // ครู/บุคลากร/ผู้บริหาร ถือเป็น staff — ไม่ต้องเปิด Monitor Agent
      out.role = roles.find((x) => x !== "student") || roles[0] || null;
    } catch { /* ignore */ }
    return out;
  }

  let lastToken = undefined;
  let pushing = false;
  let configReady = false;

  async function push() {
    if (pushing) return;
    pushing = true;
    try {
    if (!configReady) { await loadConfig(); configReady = true; }
    const s = read();
    if (!s?.access_token) {
      // ออกจากระบบแล้ว → เคลียร์ session ใน extension กันวนเปิดแท็บล็อกอินไม่หยุด
      if (typeof lastToken === "string") {
        const state = await chrome.runtime.sendMessage({ type: "GET_STATE" });
        if (state?.session?.user?.id === lastUserId) {
          const result = await chrome.runtime.sendMessage({ type: "CLEAR_SESSION" });
          if (!result?.ok) return;
        }
        lastToken = null;
      }
      return;
    }
    if (s.access_token === lastToken) return;
    const prof = s.user?.id ? await fetchProfile(s.user.id, s.access_token) : { name: null, role: null };
    if (!prof.role) return; // Retry incomplete identity; never infer student access.
    if (read()?.access_token !== s.access_token) return; // Logout/token change during identity reads.
    const result = await chrome.runtime.sendMessage({
      type: "SET_SESSION",
      backend: { url: SUPA_URL, anonKey: ANON },
      systemHome: `${location.origin}/dashboard/browser`,
      session: {
        access_token: s.access_token,
        refresh_token: s.refresh_token,
        expires_at: s.expires_at,
        role: prof.role,
        user: s.user ? { id: s.user.id, email: s.user.email, name: prof.name } : null,
      },
    });
    if (result?.ok) { lastToken = s.access_token; lastUserId = s.user?.id; }
    } finally { pushing = false; }
  }

  let lastUserId;
  const sync = () => push().catch(() => {});
  sync();
  window.addEventListener("storage", (e) => { if (e.key === KEY) sync(); });
  setInterval(sync, 10 * 1000);


  // Relay Monitor Agent commands (จาก StudentAgentPage) → extension background
  window.addEventListener("message", (ev) => {
    // ผู้ใช้กดปุ่มเปิดเว็บเอง (หน้า Safe Browser/ทางลัด) จากหน้าระบบโรงเรียนหน้าใดก็ได้
    if (ev.source === window && ev.origin === location.origin && ev.data && (ev.data.type === "SB_USER_OPEN" || (ev.data.type === "SB_OPEN_URL" && location.pathname !== "/dashboard/monitor/agent")) && typeof ev.data.url === "string") {
      // SB_OPEN_URL นอกหน้า agent = หน้าเว็บรุ่นเก่ากดเปิดเว็บเอง → ถือเป็นการเปิดของผู้ใช้
      try { chrome.runtime.sendMessage({ type: "SB_USER_OPEN", url: ev.data.url }); } catch {}
      return;
    }
    if (ev.source !== window || ev.origin !== location.origin || location.pathname !== "/dashboard/monitor/agent" || !ev.data || typeof ev.data !== "object") return;
    const t = ev.data.type;
    if (t === "SB_OPEN_URL" || t === "SB_LOCK_ALL" || t === "SB_UNLOCK_ALL" || t === "SB_SCREENSHOT") {
      try { chrome.runtime.sendMessage(ev.data); } catch {}
    }
    // คำสั่ งที่ตองได ้รบ ั คำตลบกลบั (screenshot / power) → สง่ ผลกลบั ไปหน้า agent
    if (t === "SB_CAPTURE_TAB" || t === "SB_POWER") {
      const id = ev.data.requestId;
      try {
        chrome.runtime.sendMessage(ev.data).then((result) => {
          if (id) window.postMessage({ type: "SB_RESULT", requestId: id, result: result || { ok: false } }, location.origin);
        }).catch(() => {
          if (id) window.postMessage({ type: "SB_RESULT", requestId: id, result: { ok: false, error: "extension ไม่ตอบสนอง" } }, location.origin);
        });
      } catch {}
    }
  });

  document.documentElement.setAttribute("data-school-safe-browser", "1");

  // Floating "extension linked" badge (one-time)
  if (!document.getElementById("__sb_ext_badge")) {
    const b = document.createElement("div");
    b.id = "__sb_ext_badge";
    b.textContent = "✓ ส่วนขยายเชื่อมต่อแล้ว";
    b.style.cssText = "position:fixed;bottom:12px;left:12px;background:#10b981;color:#fff;padding:6px 10px;border-radius:999px;font:12px system-ui;z-index:2147483647;box-shadow:0 4px 12px rgba(0,0,0,.15);opacity:.9";
    document.body?.appendChild(b);
    setTimeout(() => b.remove(), 3500);
  }
})();
