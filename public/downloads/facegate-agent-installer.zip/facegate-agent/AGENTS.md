- Cloud kiosks open protected school administration in the system browser through the native bridge; F9 and the visible control share it so scanning stays mounted and no device key grants admin access.
- Cloud mode exposes the same local Thai speech endpoint as the kiosk screen expects; registered avatars precede scan snapshots with explicit image fallbacks, avoiding broken pictures and missing voices.
- Native kiosk scan requests carry the visible guide mapped into upright image coordinates; scan_guide rejects partially outside faces before embedding and normalizes completed queue results to a fixed two-second pause, keeping display and recognition boundaries identical.
- Cloud idle media is delivered through device-authorized reads with fresh signed URLs; wake removes video playback and unknown attendance remains unknown rather than fabricated absence.
- Prepare offline speech from the synced Cloud roster with progress and individual failures; temporary visitor faces expire on the Bangkok day and never open doors automatically. Report operating-system failures and scheduled actions separately from completion.
- Kiosk layout follows viewport orientation without reopening the camera; calculate the visible guide from current dimensions so portrait resizing preserves scan boundaries.
- Scan speech finishes before the next voice starts, suppresses the same identity for ten seconds independently of the two-second scan pause, and includes the registered name for success, duplicates and visitors to avoid overlapping or truncated names.

- Scrolling news occupies its own flex row outside the camera stage so scan instructions never share its overlay area in either orientation.
- The screensaver grade-level attendance report reuses the homepage's shared public aggregation server-side (kiosk-api today-stats classes); offline mode groups by local class_room via saver_stats.py, and days without evidence stay unrecorded rather than fabricated absence.
